# ============================================================
# SOAL 1: Kompleksitas Waktu (Worst Case) 
# class TicketCounterSimulation
# ============================================================

"""
Analisis kompleksitas waktu worst case untuk setiap operasi
dalam class TicketCounterSimulation:

------------------------------------------------------------
1. __init__(self, numAgents, numMinutes, betweenTime, serviceTime)
------------------------------------------------------------
   - self._passengerQ = Queue()          --> O(1)
   - self._theAgents = Array(numAgents)  --> O(numAgents) = O(n)
   - for i in range(numAgents):          --> O(n) iterasi
       self._theAgents[i] = TicketAgent(i+1)  --> O(1) per iterasi
   - Assignment lainnya                  --> O(1)

   TOTAL: O(n), di mana n = numAgents

------------------------------------------------------------
2. run(self)
------------------------------------------------------------
   - for curTime in range(numMinutes + 1):  --> O(m) iterasi, m = numMinutes
       - self._handleArrival(curTime)        --> O(1) per panggilan
         (cek probabilitas + enqueue: O(1))
       - self._handleBeginService(curTime)   --> O(n) per panggilan
         (loop semua agent cari yang free: O(n))
       - self._handleEndService(curTime)     --> O(n) per panggilan
         (loop semua agent cek selesai: O(n))

   TOTAL: O(m * n), di mana m = numMinutes, n = numAgents

------------------------------------------------------------
3. printResults(self)
------------------------------------------------------------
   - numServed = self._numPassengers - len(self._passengerQ)  --> O(1)
   - avgWait = float(...) / numServed                          --> O(1)
   - print(...)                                                --> O(1)

   TOTAL: O(1)

------------------------------------------------------------
4. _handleArrival(self, curTime)   [method yang diimplementasikan]
------------------------------------------------------------
   - random check (arriveProb)   --> O(1)
   - Passenger() constructor     --> O(1)
   - enqueue ke passengerQ       --> O(1)  [asumsi linked-list queue]

   TOTAL: O(1)

------------------------------------------------------------
5. _handleBeginService(self, curTime)   [method yang diimplementasikan]
------------------------------------------------------------
   - Loop semua agent untuk cari yang free:  --> O(n)
   - Jika ada agent free dan queue tidak kosong:
       - dequeue dari passengerQ             --> O(1)
       - assign passenger ke agent           --> O(1)

   TOTAL: O(n), di mana n = numAgents

------------------------------------------------------------
6. _handleEndService(self, curTime)   [method yang diimplementasikan]
------------------------------------------------------------
   - Loop semua agent untuk cek yang sudah selesai:  --> O(n)
   - Jika agent selesai:
       - update totalWaitTime                         --> O(1)
       - update numPassengers                         --> O(1)
       - set agent menjadi free                       --> O(1)

   TOTAL: O(n), di mana n = numAgents

============================================================
RINGKASAN KOMPLEKSITAS:
============================================================

| Operasi                | Kompleksitas Worst Case          |
|------------------------|----------------------------------|
| __init__               | O(n)  -- n = numAgents           |
| run                    | O(m*n)-- m=numMinutes,n=numAgents|
| printResults           | O(1)                             |
| _handleArrival         | O(1)                             |
| _handleBeginService    | O(n)  -- n = numAgents           |
| _handleEndService      | O(n)  -- n = numAgents           |

Catatan:
- Queue menggunakan linked list --> enqueue/dequeue O(1)
- Array access --> O(1)
- Bottleneck utama ada di method run() karena nested loop
  (loop waktu x loop agent) --> O(m * n)
"""

print("=" * 60)
print("SOAL 1: ANALISIS KOMPLEKSITAS WAKTU WORST CASE")
print("class TicketCounterSimulation")
print("=" * 60)
print()
print(f"{'Operasi':<25} {'Kompleksitas Worst Case':<30} {'Keterangan'}")
print("-" * 80)
print(f"{'__init__':<25} {'O(n)':<30} n = numAgents")
print(f"{'run':<25} {'O(m * n)':<30} m = numMinutes, n = numAgents")
print(f"{'printResults':<25} {'O(1)':<30} Operasi aritmatika & print")
print(f"{'_handleArrival':<25} {'O(1)':<30} Cek prob + enqueue O(1)")
print(f"{'_handleBeginService':<25} {'O(n)':<30} Loop semua agent")
print(f"{'_handleEndService':<25} {'O(n)':<30} Loop semua agent")
print()
print("Kesimpulan: Bottleneck utama ada di method run() --> O(m * n)")
