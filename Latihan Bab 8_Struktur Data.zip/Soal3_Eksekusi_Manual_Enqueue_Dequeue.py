# ============================================================
# SOAL 3: Eksekusi Manual Queue (Enqueue + Dequeue)
# ============================================================

"""
Kode yang dieksekusi secara manual:

    values = Queue()
    for i in range(16):
        if i % 3 == 0:
            values.enqueue(i)
        elif i % 4 == 0:
            values.dequeue()

PENTING:
- Kondisi elif --> hanya dicek kalau kondisi pertama (i%3==0) FALSE
- i % 3 == 0 DAN i % 4 == 0 --> hanya if yang dieksekusi (bukan elif)
- Dequeue hanya dilakukan jika queue TIDAK kosong

------------------------------------------------------------
TRACE MANUAL LANGKAH PER LANGKAH:
------------------------------------------------------------

i=0  : 0%3==0 TRUE  --> enqueue(0)         | Queue: [0]
       (elif tidak dicek karena if sudah TRUE)

i=1  : 1%3==0 FALSE --> cek elif
       1%4==0 FALSE --> skip                | Queue: [0]

i=2  : 2%3==0 FALSE --> cek elif
       2%4==0 FALSE --> skip                | Queue: [0]

i=3  : 3%3==0 TRUE  --> enqueue(3)         | Queue: [0, 3]
       (elif tidak dicek)

i=4  : 4%3==0 FALSE --> cek elif
       4%4==0 TRUE  --> dequeue() --> keluarkan 0
                                            | Queue: [3]

i=5  : 5%3==0 FALSE --> cek elif
       5%4==0 FALSE --> skip                | Queue: [3]

i=6  : 6%3==0 TRUE  --> enqueue(6)         | Queue: [3, 6]
       (elif tidak dicek)

i=7  : 7%3==0 FALSE --> cek elif
       7%4==0 FALSE --> skip                | Queue: [3, 6]

i=8  : 8%3==0 FALSE --> cek elif
       8%4==0 TRUE  --> dequeue() --> keluarkan 3
                                            | Queue: [6]

i=9  : 9%3==0 TRUE  --> enqueue(9)         | Queue: [6, 9]
       (elif tidak dicek)

i=10 : 10%3==0 FALSE --> cek elif
       10%4==0 FALSE --> skip               | Queue: [6, 9]

i=11 : 11%3==0 FALSE --> cek elif
       11%4==0 FALSE --> skip               | Queue: [6, 9]

i=12 : 12%3==0 TRUE  --> enqueue(12)       | Queue: [6, 9, 12]
       (12%4==0 juga TRUE, tapi elif tidak dicek karena if sudah TRUE)

i=13 : 13%3==0 FALSE --> cek elif
       13%4==0 FALSE --> skip               | Queue: [6, 9, 12]

i=14 : 14%3==0 FALSE --> cek elif
       14%4==0 FALSE --> skip               | Queue: [6, 9, 12]

i=15 : 15%3==0 TRUE  --> enqueue(15)       | Queue: [6, 9, 12, 15]
       (elif tidak dicek)

------------------------------------------------------------
HASIL AKHIR QUEUE:
------------------------------------------------------------
FRONT --> [6, 9, 12, 15] <-- BACK

Jumlah elemen: 4
Yang di-enqueue: 0, 3, 6, 9, 12, 15  (6 elemen)
Yang di-dequeue: 0, 3                 (2 elemen, pada i=4 dan i=8)

Catatan penting:
- i=0  : masuk sebagai if (0%3==0), bukan elif (0%4==0)
- i=12 : masuk sebagai if (12%3==0), bukan elif (12%4==0)
  --> keduanya kelipatan 3 sekaligus kelipatan 4, tapi if menang
"""

# ============================================================
# VERIFIKASI DENGAN KODE PYTHON
# ============================================================

from collections import deque

class Queue:
    """Implementasi sederhana Queue ADT untuk verifikasi."""
    def __init__(self):
        self._data = deque()
    
    def enqueue(self, item):
        self._data.append(item)
    
    def dequeue(self):
        if not self.isEmpty():
            return self._data.popleft()
        raise IndexError("dequeue dari queue kosong")
    
    def isEmpty(self):
        return len(self._data) == 0
    
    def __len__(self):
        return len(self._data)
    
    def __repr__(self):
        return f"FRONT --> {list(self._data)} <-- BACK"


# Eksekusi kode soal dengan logging
print("=" * 65)
print("SOAL 3: EKSEKUSI MANUAL QUEUE (Enqueue + Dequeue)")
print("=" * 65)
print()
print("Kode:")
print("  values = Queue()")
print("  for i in range(16):")
print("      if i % 3 == 0:")
print("          values.enqueue(i)")
print("      elif i % 4 == 0:")
print("          values.dequeue()")
print()
print(f"{'i':<5} {'Kondisi':<30} {'Aksi':<20} {'Isi Queue'}")
print("-" * 80)

values = Queue()
for i in range(16):
    if i % 3 == 0:
        kondisi = f"{i}%3==0 TRUE"
        aksi = f"enqueue({i})"
        values.enqueue(i)
    elif i % 4 == 0:
        kondisi = f"{i}%4==0 TRUE"
        removed = values._data[0] if not values.isEmpty() else "N/A"
        aksi = f"dequeue() --> {removed}"
        values.dequeue()
    else:
        kondisi = "Keduanya FALSE"
        aksi = "skip"
    
    print(f"{i:<5} {kondisi:<30} {aksi:<20} {list(values._data)}")

print()
print(f"Hasil Akhir Queue:")
print(f"  {values}")
print(f"  Jumlah elemen: {len(values)}")
print()
print("Kesimpulan:")
print("  - Enqueue terjadi pada i = 0, 3, 6, 9, 12, 15")
print("  - Dequeue terjadi pada i = 4 (keluarkan 0) dan i = 8 (keluarkan 3)")
print("  - i=0 dan i=12: kelipatan 3 dan 4, tapi if menang atas elif")
print("  - Sisa queue akhir: [6, 9, 12, 15]")
