# ============================================================
# SOAL 4: Implementasi Metode TicketCounterSimulation
# ============================================================
# Mengimplementasikan tiga method yang tersisa:
#   - _handleArrival(curTime)
#   - _handleBeginService(curTime)
#   - _handleEndService(curTime)
# ============================================================

import random
from collections import deque


# ----------------------------------------------------------
# Kelas Queue ADT (pengganti llistqueue)
# ----------------------------------------------------------
class Queue:
    def __init__(self):
        self._data = deque()

    def enqueue(self, item):
        self._data.append(item)

    def dequeue(self):
        return self._data.popleft()

    def isEmpty(self):
        return len(self._data) == 0

    def __len__(self):
        return len(self._data)


# ----------------------------------------------------------
# Kelas Array sederhana (pengganti array module)
# ----------------------------------------------------------
class Array:
    def __init__(self, size):
        self._data = [None] * size

    def __getitem__(self, index):
        return self._data[index]

    def __setitem__(self, index, value):
        self._data[index] = value

    def __len__(self):
        return len(self._data)


# ----------------------------------------------------------
# Kelas Passenger
# ----------------------------------------------------------
class Passenger:
    def __init__(self, arrivalTime, serviceTime):
        self._arrivalTime = arrivalTime
        self._serviceTime = serviceTime

    def arrivalTime(self):
        return self._arrivalTime

    def serviceTime(self):
        return self._serviceTime


# ----------------------------------------------------------
# Kelas TicketAgent
# ----------------------------------------------------------
class TicketAgent:
    def __init__(self, agentId):
        self._agentId = agentId
        self._passenger = None    # Passenger yang sedang dilayani
        self._finishTime = 0      # Waktu selesai melayani

    def isFree(self):
        """Kembalikan True jika agent sedang tidak melayani siapapun."""
        return self._passenger is None

    def startService(self, passenger, serviceTime):
        """Mulai melayani penumpang, set waktu selesai."""
        self._passenger = passenger
        self._finishTime = serviceTime

    def isFinished(self, curTime):
        """
        Kembalikan True jika waktu layanan sudah selesai
        (agent punya passenger DAN waktu sekarang >= waktu selesai).
        """
        return (not self.isFree()) and (curTime >= self._finishTime)

    def stopService(self):
        """Selesaikan layanan, kembalikan passenger yang dilayani."""
        passenger = self._passenger
        self._passenger = None
        return passenger

    def passenger(self):
        return self._passenger


# ----------------------------------------------------------
# Kelas TicketCounterSimulation (LENGKAP)
# ----------------------------------------------------------
class TicketCounterSimulation:
    def __init__(self, numAgents, numMinutes, betweenTime, serviceTime):
        # Parameters supplied by the user.
        self._arriveProb   = 1.0 / betweenTime
        self._serviceTime  = serviceTime
        self._numMinutes   = numMinutes

        # Simulation components.
        self._passengerQ   = Queue()
        self._theAgents    = Array(numAgents)
        for i in range(numAgents):
            self._theAgents[i] = TicketAgent(i + 1)

        # Computed during the simulation.
        self._totalWaitTime  = 0
        self._numPassengers  = 0

    def run(self):
        """Jalankan simulasi menggunakan parameter yang diberikan."""
        for curTime in range(self._numMinutes + 1):
            self._handleArrival(curTime)
            self._handleBeginService(curTime)
            self._handleEndService(curTime)

    def printResults(self):
        """Cetak hasil simulasi."""
        numServed = self._numPassengers - len(self._passengerQ)
        if numServed == 0:
            avgWait = 0.0
        else:
            avgWait = float(self._totalWaitTime) / numServed
        print()
        print(f"Number of passengers served       = {numServed}")
        print(f"Number of passengers remaining in line = {len(self._passengerQ):d}")
        print(f"The average wait time was {avgWait:.2f} minutes.")

    # ----------------------------------------------------------
    # RULE #1: Penanganan kedatangan penumpang
    # ----------------------------------------------------------
    def _handleArrival(self, curTime):
        """
        Simulasi rule #1:
        Pada setiap menit, secara probabilistik tentukan apakah
        ada penumpang yang datang. Jika ya, buat objek Passenger
        dan masukkan ke antrian.
        """
        # Gunakan random untuk mensimulasikan kedatangan probabilistik
        if random.random() <= self._arriveProb:
            passenger = Passenger(curTime, self._serviceTime)
            self._passengerQ.enqueue(passenger)

    # ----------------------------------------------------------
    # RULE #2: Mulai layanan ketika ada agent bebas
    # ----------------------------------------------------------
    def _handleBeginService(self, curTime):
        """
        Simulasi rule #2:
        Jika ada agent yang bebas DAN ada penumpang dalam antrian,
        ambil penumpang dari antrian dan mulai layanan.
        """
        for i in range(len(self._theAgents)):
            agent = self._theAgents[i]
            # Cari agent yang sedang bebas
            if agent.isFree():
                # Jika ada penumpang dalam antrian
                if not self._passengerQ.isEmpty():
                    passenger = self._passengerQ.dequeue()
                    # Hitung waktu selesai: waktu sekarang + durasi layanan
                    finishTime = curTime + passenger.serviceTime()
                    agent.startService(passenger, finishTime)
                    self._numPassengers += 1

    # ----------------------------------------------------------
    # RULE #3: Selesaikan layanan yang sudah berakhir
    # ----------------------------------------------------------
    def _handleEndService(self, curTime):
        """
        Simulasi rule #3:
        Cek semua agent. Jika ada agent yang sudah selesai melayani
        penumpang, catat waktu tunggu dan bebaskan agent tersebut.
        """
        for i in range(len(self._theAgents)):
            agent = self._theAgents[i]
            # Cek apakah agent sudah selesai melayani
            if agent.isFinished(curTime):
                passenger = agent.stopService()
                # Hitung waktu tunggu: waktu mulai layanan - waktu kedatangan
                waitTime = (curTime - agent._finishTime +
                            passenger.serviceTime() - passenger.arrivalTime())
                # Cara lebih tepat: waktu layanan dimulai = finishTime - serviceTime
                startServiceTime = agent._finishTime - passenger.serviceTime()
                waitTime = startServiceTime - passenger.arrivalTime()
                self._totalWaitTime += waitTime


# ----------------------------------------------------------
# MAIN: Jalankan simulasi sebagai demo
# ----------------------------------------------------------
if __name__ == "__main__":
    print("=" * 60)
    print("SOAL 4: IMPLEMENTASI TicketCounterSimulation")
    print("=" * 60)

    # Contoh eksperimen: 2 agent, 100 menit, antara 2 menit, layanan 3 menit
    configs = [
        (2, 100,  2, 3),
        (2, 500,  2, 3),
        (2, 1000, 2, 3),
        (3, 100,  2, 4),
        (3, 500,  2, 4),
        (3, 1000, 2, 4),
    ]

    print()
    print(f"{'Agents':<8} {'Minutes':<10} {'Service':<10} {'Between':<10}")
    print("-" * 40)

    for (numAgents, numMinutes, betweenTime, serviceTime) in configs:
        print(f"\n>>> Simulasi: {numAgents} agent, {numMinutes} menit, "
              f"layanan {serviceTime} mnt, antar-kedatangan {betweenTime} mnt")
        sim = TicketCounterSimulation(numAgents, numMinutes, betweenTime, serviceTime)
        sim.run()
        sim.printResults()

    print()
    print("=" * 60)
    print("Implementasi selesai!")
    print("Tiga method yang diimplementasikan:")
    print("  1. _handleArrival    --> simulasi kedatangan (Rule #1)")
    print("  2. _handleBeginService --> mulai layanan     (Rule #2)")
    print("  3. _handleEndService   --> selesai layanan   (Rule #3)")
