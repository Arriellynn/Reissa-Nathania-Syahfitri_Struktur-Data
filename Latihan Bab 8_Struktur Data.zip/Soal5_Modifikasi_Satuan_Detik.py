# ============================================================
# SOAL 5: Modifikasi TicketCounterSimulation ke Satuan DETIK
# ============================================================
# Perubahan dari satuan menit ke detik:
# - numMinutes  --> numSeconds
# - betweenTime --> dalam detik
# - serviceTime --> dalam detik
# - printResults --> cetak "seconds" bukan "minutes"
# ============================================================

import random
from collections import deque


# ----------------------------------------------------------
# Kelas pendukung (Queue, Array, Passenger, TicketAgent)
# ----------------------------------------------------------

class Queue:
    def __init__(self):
        self._data = deque()

    def enqueue(self, item):
        self._data.append(item)

    def dequeue(self):
        return self._data.popleft()

    def isEmpty(self):
        return len(self._data) == 0

    def __len__(self):
        return len(self._data)


class Array:
    def __init__(self, size):
        self._data = [None] * size

    def __getitem__(self, index):
        return self._data[index]

    def __setitem__(self, index, value):
        self._data[index] = value

    def __len__(self):
        return len(self._data)


class Passenger:
    def __init__(self, arrivalTime, serviceTime):
        self._arrivalTime = arrivalTime
        self._serviceTime = serviceTime

    def arrivalTime(self):
        return self._arrivalTime

    def serviceTime(self):
        return self._serviceTime


class TicketAgent:
    def __init__(self, agentId):
        self._agentId   = agentId
        self._passenger = None
        self._finishTime = 0

    def isFree(self):
        return self._passenger is None

    def startService(self, passenger, finishTime):
        self._passenger  = passenger
        self._finishTime = finishTime

    def isFinished(self, curTime):
        return (not self.isFree()) and (curTime >= self._finishTime)

    def stopService(self):
        passenger = self._passenger
        self._passenger = None
        return passenger, self._finishTime


# ----------------------------------------------------------
# Kelas TicketCounterSimulation VERSI DETIK
# ----------------------------------------------------------

class TicketCounterSimulationSeconds:
    """
    Versi modifikasi TicketCounterSimulation yang menggunakan
    satuan DETIK (bukan menit).
    """

    def __init__(self, numAgents, numSeconds, betweenTime, serviceTime):
        """
        Parameters:
          numAgents   : jumlah agen loket
          numSeconds  : durasi simulasi (dalam DETIK)
          betweenTime : rata-rata waktu antar kedatangan (dalam DETIK)
          serviceTime : waktu layanan per penumpang (dalam DETIK)
        """
        # Parameters supplied by the user.
        self._arriveProb  = 1.0 / betweenTime   # probabilitas per detik
        self._serviceTime = serviceTime           # dalam detik
        self._numSeconds  = numSeconds            # ganti dari numMinutes

        # Simulation components.
        self._passengerQ  = Queue()
        self._theAgents   = Array(numAgents)
        for i in range(numAgents):
            self._theAgents[i] = TicketAgent(i + 1)

        # Computed during the simulation.
        self._totalWaitTime  = 0
        self._numPassengers  = 0

    def run(self):
        """Jalankan simulasi per detik."""
        for curTime in range(self._numSeconds + 1):   # iterasi per DETIK
            self._handleArrival(curTime)
            self._handleBeginService(curTime)
            self._handleEndService(curTime)

    def printResults(self):
        """Cetak hasil simulasi dalam satuan detik."""
        numServed = self._numPassengers - len(self._passengerQ)
        if numServed == 0:
            avgWait = 0.0
        else:
            avgWait = float(self._totalWaitTime) / numServed
        print(f"  Passengers served    : {numServed}")
        print(f"  Remaining in line    : {len(self._passengerQ)}")
        print(f"  Average wait time    : {avgWait:.2f} seconds")   # <-- detik
        return numServed, len(self._passengerQ), avgWait

    def _handleArrival(self, curTime):
        """Rule #1: Kedatangan penumpang (probabilistik per detik)."""
        if random.random() <= self._arriveProb:
            passenger = Passenger(curTime, self._serviceTime)
            self._passengerQ.enqueue(passenger)

    def _handleBeginService(self, curTime):
        """Rule #2: Mulai layanan jika ada agent bebas dan ada antrian."""
        for i in range(len(self._theAgents)):
            agent = self._theAgents[i]
            if agent.isFree() and not self._passengerQ.isEmpty():
                passenger = self._passengerQ.dequeue()
                finishTime = curTime + passenger.serviceTime()
                agent.startService(passenger, finishTime)
                self._numPassengers += 1

    def _handleEndService(self, curTime):
        """Rule #3: Selesaikan layanan yang sudah waktunya berakhir."""
        for i in range(len(self._theAgents)):
            agent = self._theAgents[i]
            if agent.isFinished(curTime):
                passenger, finishTime = agent.stopService()
                startServiceTime = finishTime - passenger.serviceTime()
                waitTime = startServiceTime - passenger.arrivalTime()
                self._totalWaitTime += waitTime


# ----------------------------------------------------------
# MAIN: Jalankan eksperimen dan cetak tabel (mirip Tabel 8.1)
# ----------------------------------------------------------

if __name__ == "__main__":
    print("=" * 75)
    print("SOAL 5: TicketCounterSimulation - Satuan DETIK")
    print("=" * 75)
    print()

    # Konfigurasi eksperimen (dalam DETIK)
    # Format: (numAgents, numSeconds, betweenTime_detik, serviceTime_detik)
    # Konversi referensi dari menit ke detik:
    #   100 menit  = 6000 detik
    #   500 menit  = 30000 detik
    #   1000 menit = 60000 detik
    #   betweenTime 2 menit = 120 detik
    #   serviceTime 3 menit = 180 detik
    #   serviceTime 4 menit = 240 detik

    configs = [
        # (numAgents, numSeconds, betweenTime, serviceTime)
        (2, 6000,  120, 180),
        (2, 30000, 120, 180),
        (2, 60000, 120, 180),
        (2, 6000,  120, 240),
        (2, 30000, 120, 240),
        (2, 60000, 120, 240),
        (3, 6000,  120, 240),
        (3, 30000, 120, 240),
        (3, 60000, 120, 240),
    ]

    # Header tabel
    header = (f"{'Num Sec':>9} | {'Num Agents':>10} | {'Avg Service':>11} | "
              f"{'Between':>7} | {'Avg Wait':>9} | {'Served':>7} | {'Remaining':>9}")
    separator = "-" * len(header)

    print("Tabel Hasil Simulasi Tiket Counter (Satuan: DETIK)")
    print(separator)
    print(header)
    print(separator)

    random.seed(42)   # seed agar hasil reproducible

    for (numAgents, numSeconds, betweenTime, serviceTime) in configs:
        sim = TicketCounterSimulationSeconds(
            numAgents, numSeconds, betweenTime, serviceTime
        )
        sim.run()
        numServed = sim._numPassengers - len(sim._passengerQ)
        numRemain = len(sim._passengerQ)
        avgWait   = (float(sim._totalWaitTime) / numServed
                     if numServed > 0 else 0.0)

        print(f"{numSeconds:>9} | {numAgents:>10} | {serviceTime:>11} | "
              f"{betweenTime:>7} | {avgWait:>9.2f} | {numServed:>7} | {numRemain:>9}")

    print(separator)
    print()
    print("Catatan konversi dari soal asli (menit --> detik):")
    print("  100  menit  =  6,000 detik")
    print("  500  menit  = 30,000 detik")
    print("  1000 menit  = 60,000 detik")
    print("  betweenTime 2 menit  = 120 detik")
    print("  serviceTime 3 menit  = 180 detik")
    print("  serviceTime 4 menit  = 240 detik")
    print()
    print("Perbedaan utama dari versi menit:")
    print("  - Parameter numMinutes  --> numSeconds")
    print("  - Loop range(numMinutes) --> range(numSeconds)")
    print("  - Output: 'minutes' --> 'seconds'")
    print("  - betweenTime & serviceTime dalam satuan detik")
