# ============================================================
# SOAL 2: Eksekusi Manual Queue (Enqueue Only)
# ============================================================

"""
Kode yang dieksekusi secara manual:

    values = Queue()
    for i in range(16):
        if i % 3 == 0:
            values.enqueue(i)

------------------------------------------------------------
TRACE MANUAL LANGKAH PER LANGKAH:
------------------------------------------------------------

Queue digambarkan sebagai: FRONT [....] BACK
Elemen baru masuk dari BACK, keluar dari FRONT.

i=0  : 0 % 3 == 0  --> TRUE  --> enqueue(0)   | Queue: [0]
i=1  : 1 % 3 == 0  --> FALSE --> skip          | Queue: [0]
i=2  : 2 % 3 == 0  --> FALSE --> skip          | Queue: [0]
i=3  : 3 % 3 == 0  --> TRUE  --> enqueue(3)   | Queue: [0, 3]
i=4  : 4 % 3 == 0  --> FALSE --> skip          | Queue: [0, 3]
i=5  : 5 % 3 == 0  --> FALSE --> skip          | Queue: [0, 3]
i=6  : 6 % 3 == 0  --> TRUE  --> enqueue(6)   | Queue: [0, 3, 6]
i=7  : 7 % 3 == 0  --> FALSE --> skip          | Queue: [0, 3, 6]
i=8  : 8 % 3 == 0  --> FALSE --> skip          | Queue: [0, 3, 6]
i=9  : 9 % 3 == 0  --> TRUE  --> enqueue(9)   | Queue: [0, 3, 6, 9]
i=10 : 10 % 3 == 0 --> FALSE --> skip          | Queue: [0, 3, 6, 9]
i=11 : 11 % 3 == 0 --> FALSE --> skip          | Queue: [0, 3, 6, 9]
i=12 : 12 % 3 == 0 --> TRUE  --> enqueue(12)  | Queue: [0, 3, 6, 9, 12]
i=13 : 13 % 3 == 0 --> FALSE --> skip          | Queue: [0, 3, 6, 9, 12]
i=14 : 14 % 3 == 0 --> FALSE --> skip          | Queue: [0, 3, 6, 9, 12]
i=15 : 15 % 3 == 0 --> TRUE  --> enqueue(15)  | Queue: [0, 3, 6, 9, 12, 15]

------------------------------------------------------------
HASIL AKHIR QUEUE:
------------------------------------------------------------
FRONT --> [0, 3, 6, 9, 12, 15] <-- BACK

Elemen yang masuk: semua kelipatan 3 dari 0 sampai 15
Jumlah elemen: 6
"""

# ============================================================
# VERIFIKASI DENGAN KODE PYTHON (menggunakan collections.deque
# sebagai pengganti Queue ADT untuk verifikasi)
# ============================================================

from collections import deque

class Queue:
    """Implementasi sederhana Queue ADT untuk verifikasi."""
    def __init__(self):
        self._data = deque()
    
    def enqueue(self, item):
        self._data.append(item)      # masuk dari back
    
    def dequeue(self):
        return self._data.popleft()  # keluar dari front
    
    def isEmpty(self):
        return len(self._data) == 0
    
    def __len__(self):
        return len(self._data)
    
    def __repr__(self):
        return f"FRONT --> {list(self._data)} <-- BACK"


# Eksekusi kode soal
values = Queue()
for i in range(16):
    if i % 3 == 0:
        values.enqueue(i)

print("=" * 60)
print("SOAL 2: EKSEKUSI MANUAL QUEUE (Enqueue Only)")
print("=" * 60)
print()
print("Kode:")
print("  values = Queue()")
print("  for i in range(16):")
print("      if i % 3 == 0:")
print("          values.enqueue(i)")
print()
print("Elemen yang di-enqueue (semua i di mana i % 3 == 0):")
print("  i = 0, 3, 6, 9, 12, 15")
print()
print(f"Isi Queue Akhir:")
print(f"  {values}")
print()
print(f"Jumlah elemen dalam queue: {len(values)}")
print()
print("Penjelasan:")
print("  range(16) menghasilkan 0 sampai 15.")
print("  Kondisi i % 3 == 0 terpenuhi untuk kelipatan 3:")
print("  yaitu 0, 3, 6, 9, 12, 15 --> 6 elemen di-enqueue.")
