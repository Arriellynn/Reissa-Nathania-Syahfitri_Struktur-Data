# ============================================================
# SOAL 6: Fungsi untuk Membalik Urutan Item dalam Queue
# ============================================================
# Aturan:
# - Hanya boleh menggunakan operasi Queue ADT (enqueue, dequeue,
#   isEmpty, len)
# - Boleh menggunakan struktur data lain sebagai bantuan
#   --> kita gunakan STACK
# ============================================================

from collections import deque


# ----------------------------------------------------------
# Implementasi Queue ADT
# ----------------------------------------------------------
class Queue:
    def __init__(self):
        self._data = deque()

    def enqueue(self, item):
        """Tambahkan item ke belakang queue."""
        self._data.append(item)

    def dequeue(self):
        """Ambil dan kembalikan item dari depan queue."""
        if self.isEmpty():
            raise IndexError("dequeue dari queue kosong")
        return self._data.popleft()

    def isEmpty(self):
        return len(self._data) == 0

    def __len__(self):
        return len(self._data)

    def __repr__(self):
        return f"FRONT --> {list(self._data)} <-- BACK"


# ----------------------------------------------------------
# Implementasi Stack (struktur data pembantu)
# ----------------------------------------------------------
class Stack:
    def __init__(self):
        self._data = []

    def push(self, item):
        self._data.append(item)

    def pop(self):
        if self.isEmpty():
            raise IndexError("pop dari stack kosong")
        return self._data.pop()

    def isEmpty(self):
        return len(self._data) == 0

    def __len__(self):
        return len(self._data)

    def __repr__(self):
        return f"BOTTOM --> {self._data} <-- TOP"


# ----------------------------------------------------------
# FUNGSI UTAMA: reverseQueue
# ----------------------------------------------------------
def reverseQueue(queue):
    """
    Membalik urutan item dalam queue menggunakan Stack sebagai pembantu.

    Algoritma:
      1. Dequeue semua item dari queue, push ke stack.
         (Stack membalik urutan karena LIFO)
      2. Pop semua item dari stack, enqueue kembali ke queue.
         (Sekarang urutan dalam queue sudah terbalik)

    Kompleksitas Waktu : O(n) -- dua kali iterasi sebanyak n elemen
    Kompleksitas Ruang : O(n) -- stack menyimpan n elemen sementara

    Parameters:
      queue : objek Queue yang akan dibalik (dimodifikasi in-place)
    """
    helper_stack = Stack()

    # Langkah 1: Pindahkan semua elemen queue ke stack
    # Stack akan membalik urutan (LIFO)
    while not queue.isEmpty():
        item = queue.dequeue()
        helper_stack.push(item)

    # Langkah 2: Pindahkan kembali dari stack ke queue
    # Pop dari stack = urutan terbalik --> masuk ke queue
    while not helper_stack.isEmpty():
        item = helper_stack.pop()
        queue.enqueue(item)

    return queue   # queue sudah dimodifikasi in-place, return untuk kenyamanan


# ----------------------------------------------------------
# MAIN: Demo dan pengujian reverseQueue
# ----------------------------------------------------------

if __name__ == "__main__":
    print("=" * 60)
    print("SOAL 6: MEMBALIK URUTAN ITEM DALAM QUEUE")
    print("=" * 60)
    print()

    # ------ Test 1: Queue berisi angka ------
    print("--- Test 1: Queue berisi angka ---")
    q1 = Queue()
    for x in [1, 2, 3, 4, 5]:
        q1.enqueue(x)
    print(f"Sebelum dibalik : {q1}")
    reverseQueue(q1)
    print(f"Setelah dibalik  : {q1}")
    print()

    # ------ Test 2: Queue berisi huruf ------
    print("--- Test 2: Queue berisi huruf ---")
    q2 = Queue()
    for c in ['A', 'B', 'C', 'D', 'E']:
        q2.enqueue(c)
    print(f"Sebelum dibalik : {q2}")
    reverseQueue(q2)
    print(f"Setelah dibalik  : {q2}")
    print()

    # ------ Test 3: Queue 1 elemen ------
    print("--- Test 3: Queue 1 elemen ---")
    q3 = Queue()
    q3.enqueue(42)
    print(f"Sebelum dibalik : {q3}")
    reverseQueue(q3)
    print(f"Setelah dibalik  : {q3}")
    print()

    # ------ Test 4: Queue kosong ------
    print("--- Test 4: Queue kosong ---")
    q4 = Queue()
    print(f"Sebelum dibalik : {q4}")
    reverseQueue(q4)
    print(f"Setelah dibalik  : {q4}")
    print()

    # ------ Test 5: Trace langkah demi langkah ------
    print("--- Test 5: Trace langkah demi langkah ---")
    q5 = Queue()
    for x in [10, 20, 30]:
        q5.enqueue(x)
    print(f"Queue awal       : {q5}")
    print()

    stack_trace = Stack()
    print("Langkah 1 - Dequeue dari queue, Push ke stack:")
    while not q5.isEmpty():
        item = q5.dequeue()
        stack_trace.push(item)
        print(f"  dequeue({item}) --> stack: {stack_trace}")
    print()

    print("Langkah 2 - Pop dari stack, Enqueue ke queue:")
    while not stack_trace.isEmpty():
        item = stack_trace.pop()
        q5.enqueue(item)
        print(f"  pop({item}) --> enqueue ke queue: {q5}")
    print()
    print(f"Hasil akhir (urutan terbalik): {q5}")
    print()

    # ------ Penjelasan Algoritma ------
    print("=" * 60)
    print("PENJELASAN ALGORITMA:")
    print("=" * 60)
    print()
    print("Ide utama: Gunakan Stack sebagai buffer sementara.")
    print()
    print("Kenapa Stack bisa membalik urutan?")
    print("  Queue [1, 2, 3, 4, 5]  (FRONT=1, BACK=5)")
    print("  Setelah dipindahkan ke Stack:")
    print("    Stack TOP --> [5, 4, 3, 2, 1] <-- BOTTOM")
    print("  Pop dari stack dan enqueue ke queue:")
    print("    Queue [5, 4, 3, 2, 1]  (FRONT=5, BACK=1) --> TERBALIK!")
    print()
    print("Kompleksitas Waktu : O(n)")
    print("Kompleksitas Ruang : O(n) -- untuk stack pembantu")
    print()
    print("Operasi Queue yang digunakan:")
    print("  - enqueue()  : menambah elemen")
    print("  - dequeue()  : mengambil elemen")
    print("  - isEmpty()  : cek apakah kosong")
